import React from "react";
import "./App.css";
import MyTaskList from "./components/My-Task-List";

function App() {
  return (
    <div>
      <MyTaskList></MyTaskList>
    </div>
  );
}

export default App;
